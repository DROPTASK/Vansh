import { useState, useEffect, useRef } from 'react';
import ThemeToggle from './ThemeToggle';

interface HeaderProps {
  toggleSidebar: () => void;
  activeTab: string;
}

export default function Header({ toggleSidebar, activeTab }: HeaderProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Capitalize first letter of tab name for header title
  const getHeaderTitle = () => {
    return activeTab.charAt(0).toUpperCase() + activeTab.slice(1);
  };
  
  return (
    <header style={{backgroundColor: 'var(--header-bg)', borderColor: 'var(--border-color)'}} className="main-header sticky top-0 z-30 h-16 border-b px-6 flex items-center justify-between shadow-sm">
      <div className="header-left flex items-center">
        <button 
          id="toggleSidebar" 
          className="p-2 rounded-full hover:bg-opacity-80"
          style={{color: 'var(--text-secondary)', backgroundColor: 'var(--hover-bg)'}}
          onClick={toggleSidebar}
        >
          <span className="material-icons">menu</span>
        </button>
      </div>
      
      <div className="header-center flex items-center">
        <span className="text-xl font-semibold text-primary-600">GOWELL</span>
      </div>
      
      <div className="header-right flex items-center gap-3">
        <ThemeToggle />
        <div className="profile-container relative" ref={dropdownRef}>
          <img 
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&h=120&q=80" 
            alt="Profile" 
            className="w-9 h-9 rounded-full object-cover cursor-pointer border-2"
            style={{borderColor: 'var(--border-color)'}}
            onClick={toggleDropdown}
          />
          {dropdownOpen && (
            <div style={{
              backgroundColor: 'var(--bg-card)',
              color: 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              boxShadow: 'var(--card-shadow)'
            }} className="dropdown-menu absolute top-12 right-0 rounded-lg w-48 z-50">
              <div className="py-2">
                <a href="#" style={{color: 'var(--text-primary)'}} className="block px-4 py-2 hover:bg-opacity-80" 
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = ''}>
                  My Profile
                </a>
                <a href="#" style={{color: 'var(--text-primary)'}} className="block px-4 py-2 hover:bg-opacity-80"
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = ''}>
                  Settings
                </a>
                <div style={{borderColor: 'var(--border-color)'}} className="border-t my-1"></div>
                <button className="w-full text-left px-4 py-2 text-red-600 hover:bg-opacity-80"
                        onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg)'}
                        onMouseOut={(e) => e.currentTarget.style.backgroundColor = ''}>
                  Logout
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
