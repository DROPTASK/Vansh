export default function QuickNavigation() {
  return (
    <div className="bg-white rounded-xl p-6 shadow-md mb-6 card-transition hover:shadow-lg">
      <h3 className="text-lg font-medium text-neutral-800 mb-4">Quick Navigation</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        <button className="ripple flex flex-col items-center justify-center p-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all">
          <span className="material-icons text-primary-500 mb-2">account_balance_wallet</span>
          <span className="text-sm">Deposit</span>
        </button>
        <button className="ripple flex flex-col items-center justify-center p-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all">
          <span className="material-icons text-primary-500 mb-2">payments</span>
          <span className="text-sm">Withdraw</span>
        </button>
        <button className="ripple flex flex-col items-center justify-center p-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all">
          <span className="material-icons text-primary-500 mb-2">group_add</span>
          <span className="text-sm">Referrals</span>
        </button>
        <button className="ripple flex flex-col items-center justify-center p-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all">
          <span className="material-icons text-primary-500 mb-2">person</span>
          <span className="text-sm">Profile</span>
        </button>
      </div>
    </div>
  );
}
