export default function DashboardCards() {
  const copyReferral = () => {
    const refLink = "https://example.com/ref123";
    navigator.clipboard.writeText(refLink).then(() => {
      alert('Referral link copied!');
    });
  };

  return (
    <div className="dashboard grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Profile Box */}
      <div className="box profile-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Profile</h3>
        <div className="flex flex-col items-center mb-4">
          <img 
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&h=120&q=80" 
            alt="Profile Photo" 
            className="w-24 h-24 rounded-full object-cover border-4 border-primary-100 mb-3"
          />
        </div>
        <div className="space-y-2">
          <p className="flex justify-between">
            <span className="text-neutral-600">Name:</span>
            <span className="font-medium">John Doe</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Account Type:</span>
            <span className="font-medium">Premium</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Total Active Direct:</span>
            <span className="font-medium">12</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Team Business:</span>
            <span className="font-medium">$45,000</span>
          </p>
        </div>
      </div>

      {/* Gain Box */}
      <div className="box gain-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Total Gain</h3>
        <div className="space-y-2">
          <p className="flex justify-between">
            <span className="text-neutral-600">Current Investment:</span>
            <span className="font-medium">$1,000</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Principal Amount:</span>
            <span className="font-medium">$500</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Profit Sharing:</span>
            <span className="font-medium">$200</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Level Growth Income:</span>
            <span className="font-medium">$150</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Gift Referral Income:</span>
            <span className="font-medium">$100</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">SIP:</span>
            <span className="font-medium">$75</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">GIP Income:</span>
            <span className="font-medium">$50</span>
          </p>
          <p className="flex justify-between">
            <span className="text-neutral-600">Reward Income:</span>
            <span className="font-medium">$30</span>
          </p>
          <div className="border-t border-neutral-200 pt-2 mt-2">
            <p className="flex justify-between font-bold">
              <span>Total Profit:</span>
              <span className="text-green-600">$1,105</span>
            </p>
          </div>
          <div className="pending-balance border-t border-neutral-200 pt-3 mt-2">
            <div className="flex justify-between items-center">
              <span className="font-medium">Pending Wallet:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium">$200</span>
                <button className="px-2 py-1 text-xs text-primary-600 border border-primary-300 rounded bg-primary-50 hover:bg-primary-100">View Details</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Balance Box */}
      <div className="box balance-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Wallet</h3>
        <div className="space-y-4">
          <p className="flex justify-between items-center">
            <span className="text-neutral-600">Top-Up Balance:</span>
            <span className="text-2xl font-bold">$300</span>
          </p>
          <p className="flex justify-between items-center">
            <span className="text-neutral-600">Withdrawable Balance:</span>
            <span className="text-2xl font-bold">$150</span>
          </p>
          <div className="wallet-buttons flex gap-3 mt-6">
            <button className="ripple flex-1 py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center justify-center">
              <span className="material-icons text-sm mr-2">add</span> Top-Up
            </button>
            <button className="ripple flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center justify-center">
              <span className="material-icons text-sm mr-2">remove</span> Withdraw
            </button>
          </div>
        </div>
      </div>

      {/* Referral Box */}
      <div className="box referral-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg col-span-1 md:col-span-2">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Referral System</h3>
        <p className="text-neutral-600 mb-2">Share your referral link:</p>
        <div className="flex items-center">
          <input 
            type="text" 
            value="https://example.com/ref123" 
            readOnly
            className="flex-1 p-3 rounded-l-lg border border-neutral-300 bg-neutral-50 text-neutral-800"
          />
          <button 
            onClick={copyReferral}
            className="ripple py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-r-lg flex items-center"
          >
            <span className="material-icons text-sm mr-2">content_copy</span> Copy
          </button>
        </div>
      </div>

      {/* Quick Navigation */}
      <div className="box nav-shortcuts bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg col-span-1 md:col-span-3">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Quick Navigation</h3>
        <div className="nav-links grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">add_circle</span>
            Deposit
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">remove_circle</span>
            Withdrawal
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">money_off</span>
            Principal Withdrawal
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">account_balance</span>
            Investments
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">group</span>
            Team
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">payments</span>
            Income
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">person</span>
            Profile
          </button>
          <button className="ripple py-3 px-4 rounded-lg border border-neutral-200 hover:border-primary-300 hover:bg-primary-50 transition-all flex items-center justify-center">
            <span className="material-icons text-primary-500 mr-2">support</span>
            Support
          </button>
        </div>
      </div>
    </div>
  );
}
