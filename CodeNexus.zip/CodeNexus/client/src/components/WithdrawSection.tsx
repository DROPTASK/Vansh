import { useState } from 'react';

export default function WithdrawSection() {
  const [method, setMethod] = useState('');
  const [amount, setAmount] = useState('');
  const [password, setPassword] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle submission logic here
    alert(`Withdrawal request submitted for $${amount} via ${method}`);
  };
  
  return (
    <div className="withdraw-container bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg max-w-lg mx-auto">
      <h3 className="text-xl font-medium text-neutral-800 mb-6">Withdraw Funds</h3>
      
      <div className="wallet-balance bg-neutral-100 p-4 rounded-lg mb-6">
        <p className="flex justify-between items-center">
          <span className="text-neutral-700">Wallet Balance:</span>
          <span className="text-xl font-bold text-primary-700">$150</span>
        </p>
      </div>
      
      <form id="withdrawForm" onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="method" className="block text-sm font-medium text-neutral-700 mb-1">
            Withdraw Method:
          </label>
          <select 
            id="method"
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            required
            className="w-full p-3 rounded-lg border border-neutral-300"
          >
            <option value="">Select Method</option>
            <option value="bank">Bank Card</option>
            <option value="usdt">USDT</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-neutral-700 mb-1">
            Amount:
          </label>
          <input 
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
            min="1"
            placeholder="Enter amount"
            className="w-full p-3 rounded-lg border border-neutral-300"
          />
        </div>
        
        <div>
          <label htmlFor="password" className="block text-sm font-medium text-neutral-700 mb-1">
            Password:
          </label>
          <input 
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            placeholder="Enter your password"
            className="w-full p-3 rounded-lg border border-neutral-300"
          />
        </div>
        
        <button 
          type="submit"
          className="ripple w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center justify-center mt-6"
        >
          <span className="material-icons text-sm mr-2">send</span> Submit Request
        </button>
      </form>
      
      <div className="mt-6 pt-4 border-t border-neutral-200">
        <h4 className="text-sm font-medium text-neutral-800 mb-2">Important Information:</h4>
        <ul className="text-xs text-neutral-600 space-y-1 list-disc pl-4">
          <li>Withdrawals are processed within 24 hours</li>
          <li>Minimum withdrawal amount is $10</li>
          <li>A 2% fee applies to all withdrawals</li>
        </ul>
      </div>
    </div>
  );
}