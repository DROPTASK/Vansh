export default function Footer() {
  return (
    <div className="mt-6 pt-6 border-t border-neutral-200 text-neutral-500 text-sm flex justify-between">
      <div>© 2023 Dashboard. All rights reserved.</div>
      <div className="flex gap-4">
        <a href="#" className="hover:text-primary-600">Privacy Policy</a>
        <a href="#" className="hover:text-primary-600">Terms of Service</a>
        <a href="#" className="hover:text-primary-600">Contact Us</a>
      </div>
    </div>
  );
}
