export default function DepositSection() {
  const copyCryptoAddress = () => {
    const address = "gowell_wallet_address_123abc";
    navigator.clipboard.writeText(address).then(() => {
      alert('Wallet address copied!');
    });
  };

  return (
    <div className="deposit-container grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-5 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-3">Deposit Funds</h3>
      </div>
      
      {/* QR Code Box */}
      <div className="qr-container bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg flex flex-col items-center justify-center">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Scan QR Code</h3>
        <div className="w-48 h-48 bg-neutral-100 rounded-lg flex items-center justify-center mb-4">
          <span className="material-icons text-6xl text-neutral-400">qr_code_2</span>
        </div>
        <p className="text-sm text-neutral-600 text-center">
          Scan this QR code with your wallet app to make a deposit
        </p>
      </div>

      {/* Deposit Form Box */}
      <div className="deposit-form-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Deposit Details</h3>
        
        {/* Crypto Address Box with Copy Button */}
        <div className="copyable-address mb-6">
          <label className="block text-sm font-medium text-neutral-700 mb-1">Wallet Address</label>
          <div className="flex">
            <input 
              type="text" 
              value="gowell_wallet_address_123abc" 
              readOnly
              className="flex-1 p-3 rounded-l-lg border border-neutral-300 bg-neutral-50 text-neutral-800 text-sm"
            />
            <button 
              onClick={copyCryptoAddress}
              className="ripple py-2 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-r-lg flex items-center"
            >
              <span className="material-icons text-sm mr-2">content_copy</span> Copy
            </button>
          </div>
        </div>
        
        <form id="depositForm" className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Amount</label>
            <input type="number" required className="w-full p-3 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Transaction ID</label>
            <input type="text" required className="w-full p-3 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Upload Proof</label>
            <input type="file" accept="image/*" required className="w-full p-2 rounded-lg border border-neutral-300" />
          </div>
          
          <button 
            type="submit" 
            className="ripple w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center justify-center mt-6"
          >
            <span className="material-icons text-sm mr-2">check_circle</span> Submit Deposit
          </button>
        </form>
      </div>
    </div>
  );
}