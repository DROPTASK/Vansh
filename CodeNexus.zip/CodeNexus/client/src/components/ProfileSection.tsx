import { useState } from 'react';

export default function ProfileSection() {
  const [passwordResetVisible, setPasswordResetVisible] = useState(false);
  const [bankEditable, setBankEditable] = useState(false);
  
  const togglePasswordReset = () => {
    setPasswordResetVisible(!passwordResetVisible);
  };
  
  const toggleBankEdit = () => {
    setBankEditable(!bankEditable);
  };
  
  return (
    <div className="dashboard grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Profile Info Form */}
      <div className="box profile-form bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">User Profile</h3>
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Sponsor ID</label>
            <input type="text" value="SP12345" readOnly className="w-full p-3 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-600" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">User ID</label>
            <input type="text" value="USR7890" readOnly className="w-full p-3 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-600" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Name</label>
            <input type="text" placeholder="Enter your name" className="w-full p-3 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
            <input type="email" value="john@example.com" readOnly className="w-full p-3 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-600" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Phone</label>
            <input type="tel" value="+91-9876543210" readOnly className="w-full p-3 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-600" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Wallet</label>
            <input type="text" placeholder="Enter your wallet address" className="w-full p-3 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Transaction Password</label>
            <input type="password" placeholder="********" className="w-full p-3 rounded-lg border border-neutral-300" />
            <button
              type="button"
              onClick={togglePasswordReset}
              className="mt-2 text-primary-600 text-sm font-medium hover:text-primary-700"
            >
              Reset Password
            </button>
          </div>
          
          {/* Password Reset Form (Hidden Initially) */}
          {passwordResetVisible && (
            <div id="resetPasswordForm" className="mt-4 p-4 border border-neutral-200 rounded-lg bg-neutral-50">
              <h4 className="text-md font-medium text-neutral-800 mb-3">Reset Transaction Password</h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Old Password</label>
                  <input type="password" className="w-full p-2 rounded-lg border border-neutral-300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">New Password</label>
                  <input type="password" className="w-full p-2 rounded-lg border border-neutral-300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Confirm New Password</label>
                  <input type="password" className="w-full p-2 rounded-lg border border-neutral-300" />
                </div>
                <button className="ripple w-full py-2 mt-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg">Submit</button>
              </div>
            </div>
          )}
          
          <button className="ripple w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center justify-center mt-6">
            <span className="material-icons text-sm mr-2">save</span> Save Profile
          </button>
        </form>
      </div>

      {/* KYC Section */}
      <div className="box kyc-box bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">KYC Verification</h3>
        
        <div className="kyc-image-wrapper mb-4">
          <div className="kyc-image-box bg-neutral-100 w-24 h-24 rounded-full mx-auto mb-2 flex items-center justify-center">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&h=120&q=80"
              alt="Profile Image"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <p className="text-center text-sm text-neutral-600">Profile Image</p>
        </div>
        
        <form id="kycForm" className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Upload Aadhaar Card front</label>
            <input type="file" className="w-full p-2 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Upload Aadhaar Card back</label>
            <input type="file" className="w-full p-2 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Upload PAN Card front</label>
            <input type="file" className="w-full p-2 rounded-lg border border-neutral-300" />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Upload PAN Card back</label>
            <input type="file" className="w-full p-2 rounded-lg border border-neutral-300" />
          </div>
          
          <button type="submit" className="ripple w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center justify-center mt-3">
            <span className="material-icons text-sm mr-2">verified</span> Submit KYC
          </button>
        </form>
      </div>

      {/* Bank Detail Section */}
      <div className="box bank-details bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg col-span-1 md:col-span-2">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Bank Details</h3>
        <form id="bankForm" className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Account Holder Name</label>
            <input 
              type="text" 
              className="bank-input w-full p-3 rounded-lg border border-neutral-300" 
              value="John Doe" 
              readOnly={!bankEditable}
              disabled={!bankEditable}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Bank Name</label>
            <input 
              type="text" 
              className="bank-input w-full p-3 rounded-lg border border-neutral-300" 
              value="XYZ Bank" 
              readOnly={!bankEditable}
              disabled={!bankEditable}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Branch Name</label>
            <input 
              type="text" 
              className="bank-input w-full p-3 rounded-lg border border-neutral-300" 
              value="New Delhi Branch" 
              readOnly={!bankEditable}
              disabled={!bankEditable}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Account Number</label>
            <input 
              type="text" 
              className="bank-input w-full p-3 rounded-lg border border-neutral-300" 
              value="123456789012" 
              readOnly={!bankEditable}
              disabled={!bankEditable}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">IFSC Code</label>
            <input 
              type="text" 
              className="bank-input w-full p-3 rounded-lg border border-neutral-300" 
              value="XYZB0000123" 
              readOnly={!bankEditable}
              disabled={!bankEditable}
            />
          </div>
          
          <div className="flex justify-between">
            {bankEditable ? (
              <>
                <button 
                  type="button" 
                  className="bank-btn ripple py-2 px-6 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  onClick={toggleBankEdit}
                >
                  Cancel
                </button>
                <button 
                  type="button" 
                  className="bank-btn ripple py-2 px-6 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
                  onClick={toggleBankEdit}
                >
                  Save
                </button>
              </>
            ) : (
              <button 
                type="button" 
                className="bank-btn ripple py-2 px-6 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
                onClick={toggleBankEdit}
              >
                Change
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}