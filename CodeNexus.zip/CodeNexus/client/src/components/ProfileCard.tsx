export default function ProfileCard() {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md card-transition hover:shadow-lg col-span-1">
      <div className="p-6 flex flex-col items-center">
        <div className="relative w-24 h-24 mb-4">
          <img 
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&h=120&q=80" 
            alt="Profile Picture" 
            className="w-full h-full rounded-full object-cover border-4 border-primary-100"
          />
          <div className="absolute bottom-0 right-0 bg-primary-600 p-1 rounded-full border-2 border-white">
            <span className="material-icons text-white" style={{ fontSize: '16px' }}>edit</span>
          </div>
        </div>
        <h3 className="text-xl font-medium text-neutral-900">John Doe</h3>
        <p className="text-neutral-600 mb-4">Member since Jan 2023</p>
        
        <div className="w-full border-t border-neutral-200 my-4"></div>
        
        <div className="w-full">
          <div className="flex justify-between py-2 border-b border-neutral-100">
            <span className="text-neutral-700">Email</span>
            <span className="text-neutral-900 font-medium">johndoe@example.com</span>
          </div>
          <div className="flex justify-between py-2 border-b border-neutral-100">
            <span className="text-neutral-700">Account ID</span>
            <span className="text-neutral-900 font-medium">USR123456</span>
          </div>
          <div className="flex justify-between py-2 border-b border-neutral-100">
            <span className="text-neutral-700">KYC Status</span>
            <span className="px-2 py-0.5 bg-green-100 text-green-800 rounded-full text-xs font-medium">Verified</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-neutral-700">2FA</span>
            <span className="px-2 py-0.5 bg-red-100 text-red-800 rounded-full text-xs font-medium">Disabled</span>
          </div>
        </div>
        
        <div className="w-full mt-6">
          <button className="ripple w-full py-3 px-4 flex items-center justify-center gap-2 bg-neutral-800 hover:bg-neutral-900 text-white rounded-lg">
            <span className="material-icons" style={{ fontSize: '18px' }}>edit</span>
            Edit Profile
          </button>
        </div>
      </div>
    </div>
  );
}
