export default function TeamSection() {
  return (
    <div className="team-container max-w-4xl mx-auto">
      <div className="box team-details bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg mb-6">
        <h3 className="text-xl font-medium text-neutral-800 mb-6">Team Overview</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gradient-to-br from-primary-50 to-primary-100 p-5 rounded-xl">
            <h4 className="text-primary-800 font-medium mb-2">Team Statistics</h4>
            <p className="text-primary-600 mb-4">Overall performance and metrics</p>
            <div className="mt-4">
              <div className="text-2xl font-bold text-primary-900">28 Members</div>
              <div className="text-green-600 font-medium">+$1,250 Team Earnings</div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-5 rounded-xl">
            <h4 className="text-blue-800 font-medium mb-2">Growth Rate</h4>
            <p className="text-blue-600 mb-4">Monthly team expansion</p>
            <div className="mt-4">
              <div className="text-2xl font-bold text-blue-900">+15%</div>
              <div className="text-neutral-600 font-medium">4 new members this month</div>
            </div>
          </div>
        </div>
        
        <div className="team-block mb-6">
          <h4 className="text-lg font-medium text-neutral-800 mb-4">Direct Team</h4>
          <div className="border border-neutral-200 rounded-lg divide-y divide-neutral-200">
            <div className="team-row flex justify-between items-center p-4">
              <span className="text-neutral-700">Active</span>
              <div className="flex items-center gap-3">
                <span className="font-medium">0</span>
                <button className="team-btn px-3 py-1 text-primary-600 border border-primary-300 rounded bg-primary-50 hover:bg-primary-100">
                  View
                </button>
              </div>
            </div>
            <div className="team-row flex justify-between items-center p-4">
              <span className="text-neutral-700">In-active</span>
              <div className="flex items-center gap-3">
                <span className="font-medium">2</span>
                <button className="team-btn px-3 py-1 text-primary-600 border border-primary-300 rounded bg-primary-50 hover:bg-primary-100">
                  View
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="team-block">
          <h4 className="text-lg font-medium text-neutral-800 mb-4">Growline Team</h4>
          <div className="border border-neutral-200 rounded-lg divide-y divide-neutral-200">
            <div className="team-row flex justify-between items-center p-4">
              <span className="text-neutral-700">Active</span>
              <div className="flex items-center gap-3">
                <span className="font-medium">0</span>
                <button className="team-btn px-3 py-1 text-primary-600 border border-primary-300 rounded bg-primary-50 hover:bg-primary-100">
                  View
                </button>
              </div>
            </div>
            <div className="team-row flex justify-between items-center p-4">
              <span className="text-neutral-700">In-active</span>
              <div className="flex items-center gap-3">
                <span className="font-medium">2</span>
                <button className="team-btn px-3 py-1 text-primary-600 border border-primary-300 rounded bg-primary-50 hover:bg-primary-100">
                  View
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="box team-members bg-white rounded-xl shadow-md p-6 card-transition hover:shadow-lg">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Direct Referrals</h3>
        
        <div className="border border-neutral-200 rounded-lg divide-y divide-neutral-200 mb-6">
          <div className="flex justify-between items-center p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">SM</div>
              <span className="text-neutral-800">Sarah Miller</span>
            </div>
            <div className="flex items-center">
              <span className="text-green-600 mr-4">+$350.00</span>
              <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
              </button>
            </div>
          </div>
          
          <div className="flex justify-between items-center p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">RJ</div>
              <span className="text-neutral-800">Robert Johnson</span>
            </div>
            <div className="flex items-center">
              <span className="text-green-600 mr-4">+$210.00</span>
              <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
              </button>
            </div>
          </div>
          
          <div className="flex justify-between items-center p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">AL</div>
              <span className="text-neutral-800">Anna Lee</span>
            </div>
            <div className="flex items-center">
              <span className="text-green-600 mr-4">+$185.00</span>
              <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
              </button>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button className="ripple py-2 px-4 border border-neutral-300 text-neutral-700 hover:bg-neutral-100 rounded-lg flex items-center">
            <span className="material-icons mr-1" style={{ fontSize: '18px' }}>people</span>
            View All Members
          </button>
          
          <button className="ripple py-2 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center">
            <span className="material-icons mr-1" style={{ fontSize: '18px' }}>share</span>
            Invite New Members
          </button>
        </div>
      </div>
    </div>
  );
}