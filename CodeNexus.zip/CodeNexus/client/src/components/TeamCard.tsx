export default function TeamCard() {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md card-transition hover:shadow-lg col-span-1 lg:col-span-2">
      <div className="p-6">
        <h3 className="text-lg font-medium text-neutral-800 mb-4">Your Team</h3>
        
        <div className="mb-6">
          <div className="bg-neutral-100 rounded-lg p-5 flex justify-between items-center">
            <div>
              <h4 className="text-lg font-medium text-neutral-900">Team Statistics</h4>
              <p className="text-neutral-600">Group performance and earnings</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-primary-700">28 Members</div>
              <div className="text-green-600">+$1,250 Team Earnings</div>
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <h4 className="text-md font-medium text-neutral-800 mb-3">Direct Referrals</h4>
          
          <div className="border border-neutral-200 rounded-lg divide-y divide-neutral-200">
            <div className="flex justify-between items-center p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">SM</div>
                <span className="text-neutral-800">Sarah Miller</span>
              </div>
              <div className="flex items-center">
                <span className="text-green-600 mr-4">+$350.00</span>
                <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                  <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
                </button>
              </div>
            </div>
            
            <div className="flex justify-between items-center p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">RJ</div>
                <span className="text-neutral-800">Robert Johnson</span>
              </div>
              <div className="flex items-center">
                <span className="text-green-600 mr-4">+$210.00</span>
                <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                  <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
                </button>
              </div>
            </div>
            
            <div className="flex justify-between items-center p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center text-primary-700 font-medium mr-3">AL</div>
                <span className="text-neutral-800">Anna Lee</span>
              </div>
              <div className="flex items-center">
                <span className="text-green-600 mr-4">+$185.00</span>
                <button className="p-1 rounded text-primary-600 hover:bg-primary-50">
                  <span className="material-icons" style={{ fontSize: '20px' }}>visibility</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button className="ripple py-2 px-4 border border-neutral-300 text-neutral-700 hover:bg-neutral-100 rounded-lg flex items-center">
            <span className="material-icons mr-1" style={{ fontSize: '18px' }}>people</span>
            View All Members
          </button>
          
          <button className="ripple py-2 px-4 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center">
            <span className="material-icons mr-1" style={{ fontSize: '18px' }}>share</span>
            Invite New Members
          </button>
        </div>
      </div>
    </div>
  );
}
