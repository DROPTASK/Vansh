import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({ isOpen, onClose, activeTab, setActiveTab }: SidebarProps) {
  
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Auto-close sidebar after selecting a tab on mobile
    if (window.innerWidth < 768) {
      onClose();
    }
  };
  
  return (
    <aside 
      className={`fixed top-0 left-0 h-screen py-6 
                  sidebar-transition z-40 shadow-md overflow-y-auto
                  ${isOpen ? 'w-64 px-4 sidebar-open' : 'w-16 px-2'}`}
      style={{
        backgroundColor: 'var(--sidebar-bg)',
        borderRight: '1px solid var(--border-color)',
        color: 'var(--text-primary)',
        boxShadow: 'var(--card-shadow)'
      }}
    >
      {/* Logo Section */}
      <div className={`logo flex justify-between items-center mb-6 ${!isOpen && 'justify-center'}`}>
        {isOpen ? (
          <>
            <span className="text-xl font-semibold text-primary-600">GOWELL</span>
            <button 
              id="closeSidebar" 
              className="p-1.5 rounded-full"
              style={{
                color: 'var(--text-secondary)',
                backgroundColor: 'var(--hover-bg)'
              }}
              onClick={onClose}
            >
              &times;
            </button>
          </>
        ) : (
          <span className="text-xl font-semibold text-primary-600">G</span>
        )}
      </div>

      {/* Navigation */}
      
      <nav>
        <ul className="space-y-1">
          <li 
            onClick={() => handleTabChange('dashboard')}
            className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer
                      ${!isOpen && 'justify-center px-1'}`}
            style={{
              color: 'var(--text-primary)',
              backgroundColor: activeTab === 'dashboard' ? 'var(--hover-bg)' : 'transparent'
            }}
            onMouseOver={(e) => {
              if (activeTab !== 'dashboard') {
                e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)';
              }
            }}
            onMouseOut={(e) => {
              if (activeTab !== 'dashboard') {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: activeTab === 'dashboard' ? 'var(--primary-color)' : 'var(--text-secondary)'}}>
              dashboard
            </span>
            {isOpen && <span>Dashboard</span>}
          </li>
          
          <li 
            onClick={() => handleTabChange('deposit')}
            className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer
                      ${!isOpen && 'justify-center px-1'}`}
            style={{
              color: 'var(--text-primary)',
              backgroundColor: activeTab === 'deposit' ? 'var(--hover-bg)' : 'transparent'
            }}
            onMouseOver={(e) => {
              if (activeTab !== 'deposit') {
                e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)';
              }
            }}
            onMouseOut={(e) => {
              if (activeTab !== 'deposit') {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`} 
                  style={{color: activeTab === 'deposit' ? 'var(--primary-color)' : 'var(--text-secondary)'}}>
              add_circle
            </span>
            {isOpen && <span>Deposit</span>}
          </li>
          
          <li 
            onClick={() => handleTabChange('withdraw')}
            className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer
                      ${!isOpen && 'justify-center px-1'}`}
            style={{
              color: 'var(--text-primary)',
              backgroundColor: activeTab === 'withdraw' ? 'var(--hover-bg)' : 'transparent'
            }}
            onMouseOver={(e) => {
              if (activeTab !== 'withdraw') {
                e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)';
              }
            }}
            onMouseOut={(e) => {
              if (activeTab !== 'withdraw') {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: activeTab === 'withdraw' ? 'var(--primary-color)' : 'var(--text-secondary)'}}>
              remove_circle
            </span>
            {isOpen && <span>Withdraw</span>}
          </li>
          
          <li 
            onClick={() => handleTabChange('profile')}
            className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer
                      ${!isOpen && 'justify-center px-1'}`}
            style={{
              color: 'var(--text-primary)',
              backgroundColor: activeTab === 'profile' ? 'var(--hover-bg)' : 'transparent'
            }}
            onMouseOver={(e) => {
              if (activeTab !== 'profile') {
                e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)';
              }
            }}
            onMouseOut={(e) => {
              if (activeTab !== 'profile') {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: activeTab === 'profile' ? 'var(--primary-color)' : 'var(--text-secondary)'}}>
              person
            </span>
            {isOpen && <span>Profile</span>}
          </li>
          
          <li 
            onClick={() => handleTabChange('team')}
            className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer
                      ${!isOpen && 'justify-center px-1'}`}
            style={{
              color: 'var(--text-primary)',
              backgroundColor: activeTab === 'team' ? 'var(--hover-bg)' : 'transparent'
            }}
            onMouseOver={(e) => {
              if (activeTab !== 'team') {
                e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)';
              }
            }}
            onMouseOut={(e) => {
              if (activeTab !== 'team') {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: activeTab === 'team' ? 'var(--primary-color)' : 'var(--text-secondary)'}}>
              group
            </span>
            {isOpen && <span>Team</span>}
          </li>
          
          <li className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer ${!isOpen && 'justify-center px-1'}`}
              style={{color: 'var(--text-primary)'}}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`} 
                  style={{color: 'var(--text-secondary)'}}>account_tree</span>
            {isOpen && <span>Tree View</span>}
          </li>
          
          <li className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer ${!isOpen && 'justify-center px-1'}`}
              style={{color: 'var(--text-primary)'}}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: 'var(--text-secondary)'}}>payment</span>
            {isOpen && <span>Income</span>}
          </li>
          
          <li className={`ripple flex items-center px-3 py-2.5 rounded-lg mb-1 font-medium transition-all duration-200 cursor-pointer ${!isOpen && 'justify-center px-1'}`}
              style={{color: 'var(--text-primary)'}}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = 'var(--hover-bg-light)'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
            <span className={`material-icons ${isOpen ? 'mr-3' : ''}`}
                  style={{color: 'var(--text-secondary)'}}>support</span>
            {isOpen && <span>Support</span>}
          </li>
        </ul>
      </nav>

      <div className="logout absolute bottom-6 left-0 w-full px-4">
        {isOpen ? (
          <button className="w-full py-2 rounded-lg transition-all duration-200 ripple"
                  style={{backgroundColor: 'var(--danger-color)', color: 'white'}}>
            Logout
          </button>
        ) : (
          <button className="w-10 h-10 mx-auto flex items-center justify-center rounded-lg transition-all duration-200 ripple"
                  style={{backgroundColor: 'var(--danger-color)', color: 'white'}}>
            <span className="material-icons">logout</span>
          </button>
        )}
      </div>
    </aside>
  );
}
