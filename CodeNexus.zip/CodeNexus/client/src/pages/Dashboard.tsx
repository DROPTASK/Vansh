import { useState, useEffect, useRef } from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import DashboardCards from "@/components/DashboardCards";
import DepositSection from "@/components/DepositSection";
import WithdrawSection from "@/components/WithdrawSection";
import ProfileSection from "@/components/ProfileSection";
import TeamSection from "@/components/TeamSection";
import Footer from "@/components/Footer";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const mainContentRef = useRef<HTMLDivElement>(null);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  const closeSidebar = () => {
    // Close sidebar only on mobile view
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };
  
  // Close sidebar when clicking in main content area on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (mainContentRef.current && 
          mainContentRef.current.contains(event.target as Node) && 
          window.innerWidth < 768) {
        setSidebarOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Render content based on active tab
  const renderTabContent = () => {
    switch(activeTab) {
      case 'dashboard':
        return <DashboardCards />;
      case 'deposit':
        return <DepositSection />;
      case 'withdraw':
        return <WithdrawSection />;
      case 'profile':
        return <ProfileSection />;
      case 'team':
        return <TeamSection />;
      default:
        return <DashboardCards />;
    }
  };

  return (
    <div className="app flex">
      {/* Fixed background */}
      <div className="fixed top-0 left-0 w-full h-full bg-gradient-to-br from-neutral-50 to-neutral-100 -z-10"></div>
      
      {/* Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={toggleSidebar} 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      
      {/* Main Content */}
      <main 
        ref={mainContentRef}
        className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-16'}`}
        id="mainContent"
        style={{ backgroundColor: 'var(--bg-main)', color: 'var(--text-primary)' }}
      >
        {/* Header */}
        <Header toggleSidebar={toggleSidebar} activeTab={activeTab} />
        
        {/* Page Content */}
        <div className="p-6" onClick={closeSidebar}>
          {/* Tab Content */}
          <div className="tab-content mb-6">
            {renderTabContent()}
          </div>
          
          {/* Footer */}
          <Footer />
        </div>
      </main>
    </div>
  );
}
