import { users, referrals, type User, type InsertUser, type Referral, type LoginUser } from "@shared/schema";
import { db } from "./db";
import { eq, or, and } from "drizzle-orm";
import { randomBytes, scrypt as _scrypt } from 'crypto';
import { promisify } from 'util';
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const scrypt = promisify(_scrypt);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsernameOrEmail(usernameOrEmail: string): Promise<User | undefined>;
  createUser(userData: Omit<InsertUser, "confirmPassword">): Promise<User>;
  getUsersByReferrer(referrerId: number): Promise<User[]>;
  createReferral(referrerId: number, referredId: number, reward?: number): Promise<Referral>;
  verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean>;
  hashPassword(password: string): Promise<string>;
  generateReferralCode(): Promise<string>;
  loginUser(loginData: LoginUser): Promise<User | null>;
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));
    
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    
    return user;
  }

  async getUserByUsernameOrEmail(usernameOrEmail: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(
        or(
          eq(users.username, usernameOrEmail),
          eq(users.email, usernameOrEmail)
        )
      );
    
    return user;
  }

  async getUsersByReferrer(referrerId: number): Promise<User[]> {
    const referredUsers = await db
      .select()
      .from(users)
      .where(eq(users.referredBy, referrerId));
    
    return referredUsers;
  }

  async createUser(userData: Omit<InsertUser, "confirmPassword">): Promise<User> {
    // Hash password
    const hashedPassword = await this.hashPassword(userData.password);
    
    // Generate referral code if not provided
    const referralCode = userData.referralCode || await this.generateReferralCode();
    
    // Create user
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword,
        referralCode,
      })
      .returning();
    
    // If user was referred by someone, create referral record
    if (userData.referredBy) {
      await this.createReferral(userData.referredBy, user.id);
    }
    
    return user;
  }

  async createReferral(referrerId: number, referredId: number, reward: number = 10): Promise<Referral> {
    const [referral] = await db
      .insert(referrals)
      .values({
        referrerId,
        referredId,
        reward
      })
      .returning();
    
    // Update the referrer's balance (typically some reward would be given)
    await db
      .update(users)
      .set({
        balance: db.sql`"balance" + ${reward}`
      })
      .where(eq(users.id, referrerId));
    
    return referral;
  }

  async generateReferralCode(): Promise<string> {
    // Generate random code
    const randomCode = randomBytes(5).toString('hex').toUpperCase();
    
    // Check if code already exists
    const [existingUser] = await db
      .select()
      .from(users)
      .where(eq(users.referralCode, randomCode));
    
    // If code exists, generate another one
    if (existingUser) {
      return this.generateReferralCode();
    }
    
    return randomCode;
  }

  async hashPassword(password: string): Promise<string> {
    const salt = randomBytes(16).toString('hex');
    const hash = (await scrypt(password, salt, 64)) as Buffer;
    return `${hash.toString('hex')}.${salt}`;
  }

  async verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
    const [hash, salt] = hashedPassword.split('.');
    const hashBuffer = Buffer.from(hash, 'hex');
    const derivedKey = (await scrypt(plainPassword, salt, 64)) as Buffer;
    
    return hashBuffer.length === derivedKey.length && 
      Buffer.compare(hashBuffer, derivedKey) === 0;
  }

  async loginUser(loginData: LoginUser): Promise<User | null> {
    // Find user by username or email
    const user = await this.getUserByUsernameOrEmail(loginData.username);
    
    // If user doesn't exist or password doesn't match, return null
    if (!user || !(await this.verifyPassword(loginData.password, user.password))) {
      return null;
    }
    
    return user;
  }
}

export const storage = new DatabaseStorage();
